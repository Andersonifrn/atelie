package br.edu.ifrn.atelie.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.ifrn.atelie.Modelo.Calculor;

public interface CalculorRepository extends JpaRepository<Calculor, Integer>{

}
