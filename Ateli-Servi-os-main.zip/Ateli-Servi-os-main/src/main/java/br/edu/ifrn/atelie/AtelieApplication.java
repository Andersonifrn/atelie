package br.edu.ifrn.atelie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtelieApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtelieApplication.class, args);
	}

}
